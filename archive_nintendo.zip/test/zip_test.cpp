#include "../source/zipx.hpp"
#include "../source/util.hpp"
#include <stdio.h>
int main(int argc, char** argv) {
    int n = 0; std::string e;
    bool ok = extract_zip(argv[1], argv[2], argv[3], n, e);
    printf("ok=%d n=%d err=%s\n", ok, n, e.c_str());
    return ok ? 0 : 1;
}
