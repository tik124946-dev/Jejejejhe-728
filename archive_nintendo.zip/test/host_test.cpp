// Хост-тест торрент-движка: ./host_test <file.torrent> <outdir> [start_file] [mem_mb]
#include "../source/swarm.hpp"
#include "../source/util.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

struct FileSink : Sink {
    std::string dir; FILE* f = nullptr; std::string err;
    bool file_begin(const Meta& m, size_t idx) override {
        std::string p = dir + "/" + m.name + (m.multi ? "/" + m.files[idx].path : "");
        size_t s = p.rfind('/');
        mkdirs(p.substr(0, s));
        f = fopen(p.c_str(), "wb");
        if (!f) { err = "open " + p; return false; }
        return true;
    }
    bool file_data(const uint8_t* p, size_t n, uint64_t) override { return fwrite(p, 1, n, f) == n; }
    bool file_end() override { fclose(f); f = nullptr; return true; }
    std::string error() override { return err; }
};

int main(int argc, char** argv) {
    if (argc < 3) return 2;
    Meta m; std::string err;
    if (!Meta::load(argv[1], m, err)) { fprintf(stderr, "load: %s\n", err.c_str()); return 3; }
    printf("name=%s files=%zu total=%llu pieces=%zu trackers=%zu\n", m.name.c_str(), m.files.size(), (unsigned long long)m.total, m.npieces, m.trackers.size());
    FileSink sk; sk.dir = argv[2];
    size_t start = argc > 3 ? (size_t)atoi(argv[3]) : 0;
    uint64_t mem = (argc > 4 ? (uint64_t)atoi(argv[4]) : 40) << 20;
    Swarm sw(m, &sk, m.files[start].off, mem);
    sw.set_file_done_cb([&](size_t i) { printf("файл готов: %s\n", m.files[i].path.c_str()); });
    uint64_t t0 = now_ms(), lastp = 0, maxbuf = 0;
    while (!sw.finished() && !sw.failed() && now_ms() - t0 < 60000) {
        sw.tick(now_ms());
        maxbuf = std::max(maxbuf, sw.buffered_bytes());
        if (now_ms() - lastp > 500) { lastp = now_ms(); printf("\r%s  %llu/%llu  %s  %s   ", sw.status_text().c_str(), (unsigned long long)sw.consumed_bytes(), (unsigned long long)m.total, human_speed(sw.speed()).c_str(), ""); fflush(stdout); }
    }
    printf("\nfinished=%d failed=%d err=%s consumed=%llu maxbuf=%llu time=%llums\n", sw.finished(), sw.failed(), sw.error().c_str(),
           (unsigned long long)sw.consumed_bytes(), (unsigned long long)maxbuf, (unsigned long long)(now_ms() - t0));
    return sw.finished() ? 0 : 1;
}
