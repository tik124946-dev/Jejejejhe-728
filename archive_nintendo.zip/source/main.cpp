// archive_nintendo — вход для Nintendo Switch (libnx). Весь интерфейс и логика в app.cpp.
#include <switch.h>
#include <stdio.h>
#include <string.h>
#include "app.hpp"
#include "nsp_install.hpp"
#include "util.hpp"

NspBackend* make_switch_backend(int storage);
bool switch_es_init();
void switch_es_exit();

static bool g_ncm = false, g_ns = false, g_es = false, g_lbl = false, g_time = false;

extern "C" void userAppInit(void) {
    appletLockExit();                      // даём время откатить недоустановленное при выходе
    // Торренту нужно 30+ соединений сразу. Памяти под сокеты по умолчанию мало (sb_efficiency = 4) —
    // при нехватке сервис сокетов отдаёт нулевое окно приёма и скорость падает почти до нуля. Берём вдвое больше.
    SocketInitConfig sc = *socketGetDefaultInitConfig();
    sc.sb_efficiency = 8;
    if (R_FAILED(socketInitialize(&sc))) socketInitializeDefault();
    g_time = R_SUCCEEDED(timeInitialize());
    g_lbl = R_SUCCEEDED(lblInitialize());
    g_ncm = R_SUCCEEDED(ncmInitialize());
    g_ns = R_SUCCEEDED(nsInitialize());
    g_es = switch_es_init();
}

extern "C" void userAppExit(void) {
    if (g_lbl) { lblSwitchBacklightOn(0); lblEnableDimming(); lblExit(); }
    switch_es_exit();
    if (g_ns) nsExit();
    if (g_ncm) ncmExit();
    if (g_time) timeExit();
    socketExit();
    appletUnlockExit();
}

class SwitchPlatform : public Platform {
public:
    std::string root() override { return "sdmc:/"; }

    bool cal(int64_t ts, TimeCalendarTime& c) {
        if (!g_time) return false;
        TimeCalendarAdditionalInfo info;
        return R_SUCCEEDED(timeToCalendarTimeWithMyRule((u64)ts, &c, &info));
    }
    int64_t epoch() override {
        u64 t = 0;
        if (g_time && R_SUCCEEDED(timeGetCurrentTime(TimeType_Default, &t))) return (int64_t)t;
        return 0;
    }
    std::string time_str() override {
        TimeCalendarTime c; char b[16];
        if (!cal(epoch(), c)) return "--:--";
        snprintf(b, sizeof b, "%02d:%02d", c.hour, c.minute);
        return b;
    }
    std::string date_str(int64_t e) override {
        TimeCalendarTime c; char b[24];
        if (!e || !cal(e, c)) return "—";
        snprintf(b, sizeof b, "%02d.%02d.%02d", c.day, c.month, c.year % 100);
        return b;
    }
    int64_t free_space(int storage) override { return space(storage, true); }
    int64_t total_space(int storage) override { return space(storage, false); }

    bool can_install() override { return g_ncm && g_ns && g_es; }
    Installer* new_installer(int storage, const std::string& resume) override {
        if (!can_install()) return nullptr;
        return new NspInstaller(make_switch_backend(storage), resume);
    }
    void discard_install(int storage, const std::string& state) override {
        if (!can_install()) return;
        NspBackend* be = make_switch_backend(storage);
        nsp_discard(be, state);
        delete be;
    }
    void keep_awake(bool on) override {
        appletSetMediaPlaybackState(on);       // отключает затемнение и автосон
        appletSetAutoSleepDisabled(on);
        if (g_lbl) { if (on) lblDisableDimming(); else lblEnableDimming(); }
    }
    void backlight(bool on) override {
        if (!g_lbl) return;
        if (on) lblSwitchBacklightOn(0); else lblSwitchBacklightOff(0);
    }

private:
    int64_t space(int storage, bool free_) {
        s64 v = 0;
        if (storage == 0) {
            FsFileSystem* fs = fsdevGetDeviceFileSystem("sdmc");
            if (!fs) return -1;
            Result rc = free_ ? fsFsGetFreeSpace(fs, "/", &v) : fsFsGetTotalSpace(fs, "/", &v);
            return R_SUCCEEDED(rc) ? v : -1;
        }
        if (!g_ncm) return -1;
        NcmContentStorage cs;
        if (R_FAILED(ncmOpenContentStorage(&cs, NcmStorageId_BuiltInUser))) return -1;
        Result rc = free_ ? ncmContentStorageGetFreeSpaceSize(&cs, &v) : ncmContentStorageGetTotalSpaceSize(&cs, &v);
        ncmContentStorageClose(&cs);
        return R_SUCCEEDED(rc) ? v : -1;
    }
};

static uint32_t map_keys(u64 d) {
    uint32_t k = 0;
    if (d & HidNpadButton_A) k |= K_A;
    if (d & HidNpadButton_B) k |= K_B;
    if (d & HidNpadButton_X) k |= K_X;
    if (d & HidNpadButton_Y) k |= K_Y;
    if (d & HidNpadButton_L) k |= K_L;
    if (d & HidNpadButton_R) k |= K_R;
    if (d & HidNpadButton_ZL) k |= K_ZL;
    if (d & HidNpadButton_ZR) k |= K_ZR;
    if (d & HidNpadButton_AnyUp) k |= K_UP;
    if (d & HidNpadButton_AnyDown) k |= K_DOWN;
    if (d & HidNpadButton_AnyLeft) k |= K_LEFT;
    if (d & HidNpadButton_AnyRight) k |= K_RIGHT;
    if (d & HidNpadButton_Plus) k |= K_PLUS;
    if (d & HidNpadButton_Minus) k |= K_MINUS;
    if (d) k |= K_ANY;                      // любая кнопка (в т. ч. стики, SL/SR) будит экран
    return k;
}

int main(int, char**) {
    padConfigureInput(8, HidNpadStyleSet_NpadStandard);
    PadState pad;
    padInitializeAny(&pad);
    hidInitializeTouchScreen();

    NWindow* win = nwindowGetDefault();
    Framebuffer fb;
    framebufferCreate(&fb, win, Gfx::W, Gfx::H, PIXEL_FORMAT_RGBA_8888, 2);
    framebufferMakeLinear(&fb);

    SwitchPlatform pf;
    App* app = new App(&pf);
    app->init();
    Gfx* g = new Gfx;
    bool touch_prev = false;

    while (appletMainLoop()) {
        padUpdate(&pad);
        uint32_t keys = map_keys(padGetButtonsDown(&pad));
        HidTouchScreenState ts = {0};
        bool touch = hidGetTouchScreenStates(&ts, 1) > 0 && ts.count > 0;
        if (touch && !touch_prev) keys |= K_ANY;
        touch_prev = touch;

        uint64_t now = now_ms();
        if (!app->frame(keys, now)) break;

        if (app->dirty(now)) {
            app->draw(*g, now);
            u32 stride;
            u8* out = (u8*)framebufferBegin(&fb, &stride);
            for (int y = 0; y < Gfx::H; y++) memcpy(out + (size_t)y * stride, &g->px[(size_t)y * Gfx::W], Gfx::W * 4);
            framebufferEnd(&fb);
        } else if (!app->job_running()) {
            svcSleepThread(16000000ULL);
        }
    }

    delete app;                             // откатывает недоустановленные NSP и возвращает подсветку
    delete g;
    framebufferClose(&fb);
    return 0;
}
