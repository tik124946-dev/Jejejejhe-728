#pragma once
#include <string>

// Распаковка .zip с портами/хомбрю по правилам маршрутизации (switch/, atmosphere/, config/ …).
// Возвращает true, если всё распаковано. n_files — сколько файлов записано.
bool extract_zip(const std::string& zip_path, const std::string& root, const std::string& name, int& n_files, std::string& err);
