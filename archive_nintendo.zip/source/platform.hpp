#pragma once
#include <stdint.h>
#include <string>

// Установщик NSP: данные подаются потоком, на карте памяти не лежит ничего лишнего.
struct Installer {
    virtual ~Installer() {}
    // off — смещение в NSP; если оно больше ожидаемого, часть пропущена (уже установлена)
    virtual bool write(uint64_t off, const uint8_t* p, size_t n) = 0;
    virtual bool take_seek(uint64_t& off) { (void)off; return false; }   // просьба пропустить до смещения off
    virtual bool finish() = 0;            // регистрация в базе (ncm/ns/es)
    virtual void abort() = 0;             // полный откат: удаляем всё, что успели поставить
    virtual std::string suspend() { abort(); return ""; }   // остановка с сохранением частичной установки; вернёт состояние
    virtual std::string state() { return ""; }              // состояние для сохранения на диск (для продолжения)
    virtual std::string error() = 0;
    virtual std::string info() = 0;       // что ставится (ID игры и т. д.)
};

// Всё, что зависит от железа. На Switch — libnx, на хосте — заглушка для тестов.
struct Platform {
    virtual ~Platform() {}
    virtual std::string root() = 0;                       // "sdmc:/"
    virtual std::string time_str() = 0;                   // "14:05"
    virtual int64_t epoch() = 0;                          // секунды (UTC)
    virtual std::string date_str(int64_t epoch) = 0;      // "23.11.26"
    virtual int64_t free_space(int storage) = 0;          // 0 — SD, 1 — память консоли; -1 если неизвестно
    virtual int64_t total_space(int storage) = 0;
    virtual bool can_install() = 0;                       // доступна ли установка NSP (ncm/ns/es)
    // resume — состояние, сохранённое прошлым запуском (пусто — установка с нуля)
    virtual Installer* new_installer(int storage, const std::string& resume) = 0;
    // Удалить недоустановленное (при отмене): состояние из Installer::state()
    virtual void discard_install(int storage, const std::string& state) = 0;
    virtual void keep_awake(bool on) = 0;                 // запретить сон/затемнение
    virtual void backlight(bool on) = 0;                  // подсветка экрана
};
