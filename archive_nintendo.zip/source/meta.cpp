#include "meta.hpp"
#include "bencode.hpp"
#include "sha1.hpp"
#include "util.hpp"

static std::string clean_comp(std::string c) {
    for (auto& ch : c) {
        unsigned char u = (unsigned char)ch;
        if (u < 0x20 || ch == ':' || ch == '*' || ch == '?' || ch == '"' || ch == '<' || ch == '>' || ch == '|' || ch == '\\') ch = '_';
    }
    while (!c.empty() && (c.back() == '.' || c.back() == ' ')) c.pop_back();
    while (!c.empty() && c.front() == ' ') c.erase(0, 1);
    if (c.size() > 200) c.resize(200);
    return c;
}

std::string sanitize_rel_path(const std::string& p) {
    std::string out, cur;
    auto flush = [&]() {
        std::string c = clean_comp(cur);
        cur.clear();
        if (c.empty() || c == "." || c == "..") return;
        if (!out.empty()) out += '/';
        out += c;
    };
    for (char ch : p) {
        if (ch == '/') flush(); else cur += ch;
    }
    flush();
    return out;
}

static const BVal* pick(const BVal& d, const char* utf8key, const char* key) {
    const BVal* v = d.get(utf8key);
    if (v) return v;
    return d.get(key);
}

bool Meta::load(const std::string& path, Meta& m, std::string& err) {
    std::vector<uint8_t> data;
    if (!read_file(path, data, 32u << 20)) { err = "не удалось прочитать .torrent"; return false; }
    BVal root;
    size_t pos = 0;
    if (!bdecode(data.data(), data.size(), pos, root) || root.t != BVal::DICT) { err = "это не .torrent (bencode)"; return false; }
    const BVal* info = root.get("info");
    if (!info || info->t != BVal::DICT) { err = "нет раздела info"; return false; }

    Sha1::hash(data.data() + info->b, info->e - info->b, m.infohash);

    const BVal* nm = pick(*info, "name.utf-8", "name");
    const BVal* pl = info->get("piece length");
    const BVal* pc = info->get("pieces");
    if (!nm || nm->t != BVal::STR || !pl || pl->t != BVal::INT || pl->i <= 0 || !pc || pc->t != BVal::STR || pc->s.size() % 20) {
        err = "повреждённый info"; return false;
    }
    if (info->get("meta version") && !info->get("pieces")) { err = "торрент v2 не поддерживается"; return false; }
    m.name = sanitize_rel_path(nm->s);
    if (m.name.empty()) m.name = "torrent";
    m.plen = (uint64_t)pl->i;
    if (m.plen > (64u << 20)) { err = "слишком большой размер куска"; return false; }
    m.hashes.assign(pc->s.begin(), pc->s.end());

    m.files.clear();
    const BVal* files = info->get("files");
    uint64_t off = 0;
    if (files && files->t == BVal::LIST) {
        m.multi = true;
        for (auto& f : files->l) {
            const BVal* ln = f.get("length");
            const BVal* pt = pick(f, "path.utf-8", "path");
            if (!ln || ln->t != BVal::INT || ln->i < 0 || !pt || pt->t != BVal::LIST || pt->l.empty()) { err = "повреждённый список файлов"; return false; }
            std::string rel;
            for (auto& c : pt->l) { if (c.t != BVal::STR) { err = "повреждённый путь"; return false; } rel += c.s + "/"; }
            TFile tf;
            tf.path = sanitize_rel_path(rel);
            tf.off = off; tf.len = (uint64_t)ln->i;
            const BVal* at = f.get("attr");
            if (at && at->t == BVal::STR && at->s.find('p') != std::string::npos) tf.pad = true;
            if (tf.path.empty()) { err = "пустой путь файла"; return false; }
            off += tf.len;
            m.files.push_back(tf);
        }
    } else {
        const BVal* ln = info->get("length");
        if (!ln || ln->t != BVal::INT || ln->i < 0) { err = "нет длины файла"; return false; }
        m.multi = false;
        TFile tf; tf.path = m.name; tf.off = 0; tf.len = (uint64_t)ln->i;
        off = tf.len;
        m.files.push_back(tf);
    }
    if (m.files.empty()) { err = "в торренте нет файлов"; return false; }
    m.total = off;
    m.npieces = (size_t)((m.total + m.plen - 1) / m.plen);
    if (m.npieces != m.hashes.size() / 20) { err = "число кусков не совпадает с размером"; return false; }

    m.trackers.clear();
    auto add = [&](const std::string& t) {
        for (auto& x : m.trackers) if (x == t) return;
        m.trackers.push_back(t);
    };
    const BVal* al = root.get("announce-list");
    if (al && al->t == BVal::LIST)
        for (auto& tier : al->l)
            if (tier.t == BVal::LIST) for (auto& t : tier.l) if (t.t == BVal::STR) add(t.s);
    const BVal* an = root.get("announce");
    if (an && an->t == BVal::STR) add(an->s);
    return true;
}
