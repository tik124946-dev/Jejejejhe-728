// Установка NSP через системные сервисы Switch: ncm (контент), es (билеты), ns (запись приложения).
// ВНИМАНИЕ: код написан по документации libnx/switchbrew и проверен только на логике (тесты на заглушке),
// на реальной консоли требует проверки.
#include <switch.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include "nsp_install.hpp"
#include "util.hpp"

static Service g_es;
static bool g_es_ok = false;

bool switch_es_init() { g_es_ok = R_SUCCEEDED(smGetService(&g_es, "es")); return g_es_ok; }
void switch_es_exit() { if (g_es_ok) { serviceClose(&g_es); g_es_ok = false; } }

static std::string rs(Result rc) {
    char b[96];
    snprintf(b, sizeof b, "0x%X (модуль %u, код %u)", (unsigned)rc, (unsigned)R_MODULE(rc), (unsigned)R_DESCRIPTION(rc));
    return b;
}

namespace {
class SwitchBackend : public NspBackend {
public:
    explicit SwitchBackend(NcmStorageId sid) : sid_(sid) {}
    ~SwitchBackend() override {
        if (ph_open_) ncmContentStorageDeletePlaceHolder(&cs_, &ph_);
        if (opened_) { ncmContentMetaDatabaseClose(&db_); ncmContentStorageClose(&cs_); }
    }

    bool open(bool cleanup, std::string& err) override {
        Result rc = ncmOpenContentStorage(&cs_, sid_);
        if (R_FAILED(rc)) { err = "ncmOpenContentStorage " + rs(rc); return false; }
        rc = ncmOpenContentMetaDatabase(&db_, sid_);
        if (R_FAILED(rc)) { ncmContentStorageClose(&cs_); err = "ncmOpenContentMetaDatabase " + rs(rc); return false; }
        opened_ = true;
        if (cleanup) ncmContentStorageCleanupAllPlaceHolder(&cs_);   // убираем хвосты прерванных установок
        return true;
    }

    // Продолжение прерванной записи: placeholder переживает перезапуск приложения (до перезагрузки консоли)
    int resume_content(const uint8_t cid[16], const std::string& ph_hex, std::string& err) override {
        NcmContentId id; memcpy(id.c, cid, 16);
        bool has = false;
        if (R_SUCCEEDED(ncmContentStorageHas(&cs_, &has, &id)) && has) return 1;
        NcmPlaceHolderId ph;
        if (!from_hex(ph_hex, ph.uuid.uuid, 16)) { err = "плохой id placeholder"; return -1; }
        bool hp = false;
        Result rc = ncmContentStorageHasPlaceHolder(&cs_, &hp, &ph);
        if (R_FAILED(rc) || !hp) { err = "placeholder пропал (после перезагрузки консоли) — NCA начнётся заново"; return -1; }
        ph_ = ph; ph_open_ = true;
        return 0;
    }

    std::string placeholder_hex() override { return to_hex(ph_.uuid.uuid, 16); }
    void detach() override { ph_open_ = false; }                  // оставляем placeholder на месте
    void delete_placeholder(const std::string& ph_hex) override {
        NcmPlaceHolderId ph;
        if (from_hex(ph_hex, ph.uuid.uuid, 16)) ncmContentStorageDeletePlaceHolder(&cs_, &ph);
    }

    int begin_content(const uint8_t cid[16], uint64_t size, std::string& err) override {
        NcmContentId id; memcpy(id.c, cid, 16);
        bool has = false;
        if (R_SUCCEEDED(ncmContentStorageHas(&cs_, &has, &id)) && has) return 1;
        Result rc = ncmContentStorageGeneratePlaceHolderId(&cs_, &ph_);
        if (R_FAILED(rc)) { err = "GeneratePlaceHolderId " + rs(rc); return -1; }
        rc = ncmContentStorageCreatePlaceHolder(&cs_, &id, &ph_, (s64)size);
        if (R_FAILED(rc)) {
            err = "CreatePlaceHolder " + rs(rc);
            if (R_DESCRIPTION(rc) == 0x1 || R_MODULE(rc) == 0x10) err += " — возможно, не хватает места";
            return -1;
        }
        ph_open_ = true;
        return 0;
    }

    bool write_content(uint64_t off, const uint8_t* p, size_t n, std::string& err) override {
        while (n) {
            size_t k = n > 0x100000 ? 0x100000 : n;
            Result rc = ncmContentStorageWritePlaceHolder(&cs_, &ph_, off, p, k);
            if (R_FAILED(rc)) { err = "WritePlaceHolder " + rs(rc); return false; }
            off += k; p += k; n -= k;
        }
        return true;
    }

    bool end_content(const uint8_t cid[16], std::string& err) override {
        NcmContentId id; memcpy(id.c, cid, 16);
        Result rc = ncmContentStorageRegister(&cs_, &id, &ph_);
        ph_open_ = false;
        if (R_FAILED(rc)) {
            ncmContentStorageDeletePlaceHolder(&cs_, &ph_);
            err = "Register " + rs(rc);
            return false;
        }
        return true;
    }

    void abort_content() override {
        if (ph_open_) { ncmContentStorageDeletePlaceHolder(&cs_, &ph_); ph_open_ = false; }
    }

    void delete_content(const uint8_t cid[16]) override {
        NcmContentId id; memcpy(id.c, cid, 16);
        ncmContentStorageDelete(&cs_, &id);
    }

    // CNMT лежит внутри «мета»-NCA; система сама расшифровывает его при монтировании ContentMeta-ФС.
    bool read_cnmt(const uint8_t cid[16], std::vector<uint8_t>& out, std::string& err) override {
        NcmContentId id; memcpy(id.c, cid, 16);
        char path[FS_MAX_PATH] = {0};
        Result rc = ncmContentStorageGetPath(&cs_, path, sizeof path, &id);
        if (R_FAILED(rc)) { err = "GetPath " + rs(rc); return false; }
        FsFileSystem fs;
        rc = fsOpenFileSystemWithId(&fs, 0, FsFileSystemType_ContentMeta, path, FsContentAttributes_All);
        if (R_FAILED(rc)) { err = "fsOpenFileSystemWithId " + rs(rc); return false; }
        bool ok = false;
        FsDir dir;
        if (R_SUCCEEDED(fsFsOpenDirectory(&fs, "/", FsDirOpenMode_ReadFiles, &dir))) {
            FsDirectoryEntry ent; s64 cnt = 0;
            std::string found;
            while (R_SUCCEEDED(fsDirRead(&dir, &cnt, 1, &ent)) && cnt == 1) {
                if (ends_with_ci(ent.name, ".cnmt")) { found = ent.name; break; }
            }
            fsDirClose(&dir);
            if (!found.empty()) {
                FsFile f; std::string fp = "/" + found;
                if (R_SUCCEEDED(fsFsOpenFile(&fs, fp.c_str(), FsOpenMode_Read, &f))) {
                    s64 sz = 0;
                    if (R_SUCCEEDED(fsFileGetSize(&f, &sz)) && sz > 0 && sz < (8 << 20)) {
                        out.resize((size_t)sz);
                        u64 got = 0;
                        if (R_SUCCEEDED(fsFileRead(&f, 0, out.data(), (u64)sz, FsReadOption_None, &got)) && got == (u64)sz) ok = true;
                    }
                    fsFileClose(&f);
                }
            }
        }
        fsFsClose(&fs);
        if (!ok) err = "не удалось прочитать CNMT из мета-NCA";
        return ok;
    }

    // es: ImportTicket (cmd 1): билет и сертификат
    bool import_ticket(const std::vector<uint8_t>& tik, const std::vector<uint8_t>& cert, std::string& err) override {
        if (!g_es_ok) { err = "сервис es недоступен"; return false; }
        Result rc = serviceDispatch(&g_es, 1,
            .buffer_attrs = { SfBufferAttr_HipcMapAlias | SfBufferAttr_In, SfBufferAttr_HipcMapAlias | SfBufferAttr_In },
            .buffers = { { tik.data(), tik.size() }, { cert.data(), cert.size() } });
        if (R_FAILED(rc)) { err = "ImportTicket " + rs(rc); return false; }
        return true;
    }

    bool set_meta(uint64_t id, uint32_t ver, uint8_t type, const std::vector<uint8_t>& rec, std::string& err) override {
        NcmContentMetaKey key; memset(&key, 0, sizeof key);
        key.id = id; key.version = ver; key.type = type; key.install_type = NcmContentInstallType_Full;
        Result rc = ncmContentMetaDatabaseSet(&db_, &key, rec.data(), rec.size());
        if (R_FAILED(rc)) { err = "ContentMetaDatabase.Set " + rs(rc); return false; }
        return true;
    }

    bool commit_meta(std::string& err) override {
        Result rc = ncmContentMetaDatabaseCommit(&db_);
        if (R_FAILED(rc)) { err = rs(rc); return false; }
        return true;
    }

    // ns: PushApplicationRecord (cmd 16) — чтобы игра появилась в HOME-меню
    bool push_record(uint64_t app_id, uint64_t id, uint32_t ver, uint8_t type, std::string& err) override {
        struct { NcmContentMetaKey key; u8 storage_id; u8 pad[7]; } rec;
        memset(&rec, 0, sizeof rec);
        rec.key.id = id; rec.key.version = ver; rec.key.type = type; rec.key.install_type = NcmContentInstallType_Full;
        rec.storage_id = (u8)sid_;
        struct { u8 event; u8 pad[7]; u64 app; } in;
        memset(&in, 0, sizeof in);
        in.event = 3;                                            // NsApplicationEvent_Present
        in.app = app_id;
        Service srv = {0}, *sp = &srv;
        Result rc = 0;
        if (hosversionAtLeast(3, 0, 0)) rc = nsGetApplicationManagerInterface(&srv);
        else sp = nsGetServiceSession_ApplicationManagerInterface();
        if (R_SUCCEEDED(rc)) rc = serviceDispatchIn(sp, 16, in,
            .buffer_attrs = { SfBufferAttr_HipcMapAlias | SfBufferAttr_In },
            .buffers = { { &rec, sizeof rec } });
        if (hosversionAtLeast(3, 0, 0)) serviceClose(&srv);
        if (R_FAILED(rc)) { err = "PushApplicationRecord " + rs(rc); return false; }
        return true;
    }

private:
    NcmStorageId sid_;
    NcmContentStorage cs_;
    NcmContentMetaDatabase db_;
    NcmPlaceHolderId ph_;
    bool opened_ = false, ph_open_ = false;
};
}

NspBackend* make_switch_backend(int storage) {
    return new SwitchBackend(storage == 0 ? NcmStorageId_SdCard : NcmStorageId_BuiltInUser);
}
