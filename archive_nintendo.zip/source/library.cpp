#include "library.hpp"
#include "util.hpp"
#include <stdlib.h>

static std::string clean(std::string s) { for (auto& c : s) if (c == '\t' || c == '\n' || c == '\r') c = ' '; return s; }

bool Library::load(const std::string& p) {
    path = p; items.clear();
    std::vector<uint8_t> d;
    if (!read_file(p, d, 8u << 20)) return false;
    std::string s((const char*)d.data(), d.size());
    size_t pos = 0;
    while (pos < s.size()) {
        size_t e = s.find('\n', pos);
        if (e == std::string::npos) e = s.size();
        std::string line = s.substr(pos, e - pos); pos = e + 1;
        std::vector<std::string> f; size_t a = 0;
        for (;;) { size_t t = line.find('\t', a); if (t == std::string::npos) { f.push_back(line.substr(a)); break; } f.push_back(line.substr(a, t - a)); a = t + 1; }
        if (f.size() < 8) continue;
        LibEntry en;
        en.hash = f[0]; en.name = f[1]; en.total = strtoull(f[2].c_str(), nullptr, 10);
        en.files_done = (uint32_t)atoi(f[3].c_str()); en.files_total = (uint32_t)atoi(f[4].c_str());
        en.status = atoi(f[5].c_str()); en.when = strtoll(f[6].c_str(), nullptr, 10); en.note = f[7];
        if (f.size() > 8) en.tpath = f[8];
        if (f.size() > 9) en.cur_off = strtoull(f[9].c_str(), nullptr, 10);
        if (f.size() > 10) en.inst = f[10];
        if (f.size() > 11) en.mode = atoi(f[11].c_str()) == 1 ? 1 : 0;
        items.push_back(en);
    }
    return true;
}

bool Library::save() {
    std::string s;
    for (auto& e : items)
        s += e.hash + "\t" + clean(e.name) + "\t" + std::to_string(e.total) + "\t" + std::to_string(e.files_done) + "\t" + std::to_string(e.files_total) +
             "\t" + std::to_string(e.status) + "\t" + std::to_string((long long)e.when) + "\t" + clean(e.note) + "\t" + clean(e.tpath) + "\t" + std::to_string(e.cur_off) + "\t" + clean(e.inst) + "\t" + std::to_string(e.mode) + "\n";
    return write_file(path, s);
}

LibEntry* Library::find(const std::string& h) {
    for (auto& e : items) if (e.hash == h) return &e;
    return nullptr;
}

void Library::upsert(const LibEntry& e) {
    if (LibEntry* x = find(e.hash)) *x = e; else items.push_back(e);
}

void Library::remove(const std::string& h) {
    for (size_t i = 0; i < items.size(); i++) if (items[i].hash == h) { items.erase(items.begin() + i); return; }
}
