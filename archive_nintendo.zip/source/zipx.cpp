#include "zipx.hpp"
#include "router.hpp"
#include "meta.hpp"
#include "util.hpp"
#include <stdio.h>
#include <string.h>
#include <zlib.h>
#include <vector>

static uint16_t r16(const uint8_t* p) { return (uint16_t)(p[0] | p[1] << 8); }
static uint32_t r32(const uint8_t* p) { return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }

struct ZEnt { std::string name; uint16_t flags, method; uint32_t crc, csize, usize, off; };

static bool pread(FILE* f, uint64_t off, void* buf, size_t n) {
    if (fseek(f, (long)off, SEEK_SET) != 0) return false;
    return fread(buf, 1, n, f) == n;
}

bool extract_zip(const std::string& zip_path, const std::string& root, const std::string& name, int& n_files, std::string& err) {
    n_files = 0;
    FILE* f = fopen(zip_path.c_str(), "rb");
    if (!f) { err = "не удалось открыть zip"; return false; }
    struct Closer { FILE* f; ~Closer() { fclose(f); } } closer{f};
    fseek(f, 0, SEEK_END);
    long fsz = ftell(f);
    if (fsz < 22) { err = "zip слишком мал"; return false; }
    long tail = std::min<long>(fsz, 65557);
    std::vector<uint8_t> tb((size_t)tail);
    if (!pread(f, (uint64_t)(fsz - tail), tb.data(), (size_t)tail)) { err = "ошибка чтения zip"; return false; }
    long e = -1;
    for (long i = tail - 22; i >= 0; i--) if (r32(&tb[(size_t)i]) == 0x06054b50) { e = i; break; }
    if (e < 0) { err = "это не zip (нет EOCD)"; return false; }
    uint16_t total = r16(&tb[(size_t)e + 10]);
    uint32_t cdsz = r32(&tb[(size_t)e + 12]), cdoff = r32(&tb[(size_t)e + 16]);
    if (total == 0xFFFF || cdsz == 0xFFFFFFFFu || cdoff == 0xFFFFFFFFu) { err = "zip64 (больше 4 ГБ) не поддерживается"; return false; }
    if (cdsz > (32u << 20) || (uint64_t)cdoff + cdsz > (uint64_t)fsz) { err = "повреждённый zip"; return false; }
    std::vector<uint8_t> cd(cdsz);
    if (!pread(f, cdoff, cd.data(), cdsz)) { err = "ошибка чтения zip"; return false; }

    std::vector<ZEnt> ents;
    size_t p = 0;
    bool has_nro = false;
    while (p + 46 <= cd.size() && r32(&cd[p]) == 0x02014b50) {
        ZEnt z;
        z.flags = r16(&cd[p + 8]); z.method = r16(&cd[p + 10]); z.crc = r32(&cd[p + 16]);
        z.csize = r32(&cd[p + 20]); z.usize = r32(&cd[p + 24]);
        uint16_t nl = r16(&cd[p + 28]), el = r16(&cd[p + 30]), cl = r16(&cd[p + 32]);
        z.off = r32(&cd[p + 42]);
        if (p + 46 + nl > cd.size()) break;
        z.name.assign((const char*)&cd[p + 46], nl);
        p += 46 + (size_t)nl + el + cl;
        if (z.name.empty() || z.name.back() == '/') continue;                    // папки
        if (z.name.compare(0, 9, "__MACOSX/") == 0 || z.name.find(".DS_Store") != std::string::npos) continue;
        if (ends_with_ci(z.name, ".nro")) has_nro = true;
        ents.push_back(z);
    }
    if (ents.empty()) { err = "в zip нет файлов"; return false; }

    std::string tname = sanitize_rel_path(name);
    std::vector<uint8_t> in, out;
    for (auto& z : ents) {
        if (z.flags & 1) { err = "zip защищён паролем"; return false; }
        std::string rel = sanitize_rel_path(z.name);
        if (rel.empty()) continue;
        uint8_t lh[30];
        if (!pread(f, z.off, lh, 30) || r32(lh) != 0x04034b50) { err = "повреждённый zip (заголовок)"; return false; }
        uint64_t data = (uint64_t)z.off + 30 + r16(lh + 26) + r16(lh + 28);
        std::string dest = route_dest(root, tname, true, rel, has_nro);
        size_t sl = dest.rfind('/');
        if (sl != std::string::npos && !mkdirs(dest.substr(0, sl))) { err = "не удалось создать папку для " + dest; return false; }
        FILE* o = fopen(dest.c_str(), "wb");
        if (!o) { err = "не удалось создать " + dest; return false; }
        uint32_t crc = crc32(0, nullptr, 0);
        bool ok = true;
        if (z.method == 0) {
            if (fseek(f, (long)data, SEEK_SET) != 0) ok = false;
            uint8_t buf[32768]; uint32_t left = z.usize;
            while (ok && left) {
                size_t k = std::min<uint32_t>(left, sizeof buf);
                if (fread(buf, 1, k, f) != k || fwrite(buf, 1, k, o) != k) { ok = false; break; }
                crc = crc32(crc, buf, (uInt)k); left -= (uint32_t)k;
            }
        } else if (z.method == 8) {
            z_stream zs; memset(&zs, 0, sizeof zs);
            if (inflateInit2(&zs, -15) != Z_OK) ok = false;
            else {
                if (fseek(f, (long)data, SEEK_SET) != 0) ok = false;
                uint32_t left = z.csize; int r = Z_OK;
                uint8_t ib[32768], ob[65536];
                while (ok && r != Z_STREAM_END) {
                    if (zs.avail_in == 0) {
                        size_t k = std::min<uint32_t>(left, sizeof ib);
                        if (k == 0 || fread(ib, 1, k, f) != k) { ok = false; break; }
                        left -= (uint32_t)k; zs.next_in = ib; zs.avail_in = (uInt)k;
                    }
                    zs.next_out = ob; zs.avail_out = sizeof ob;
                    r = inflate(&zs, Z_NO_FLUSH);
                    if (r != Z_OK && r != Z_STREAM_END) { ok = false; break; }
                    size_t got = sizeof ob - zs.avail_out;
                    if (got && fwrite(ob, 1, got, o) != got) { ok = false; break; }
                    crc = crc32(crc, ob, (uInt)got);
                }
                inflateEnd(&zs);
            }
        } else { ok = false; err = "метод сжатия " + std::to_string(z.method) + " не поддерживается"; }
        bool closed = fclose(o) == 0;
        if (!ok || !closed) { if (err.empty()) err = "ошибка распаковки " + rel; return false; }
        if (crc != z.crc) { err = "контрольная сумма не совпала: " + rel; return false; }
        n_files++;
    }
    return true;
}
