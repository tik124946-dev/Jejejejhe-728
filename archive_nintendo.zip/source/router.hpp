#pragma once
#include "sink.hpp"
#include "meta.hpp"
#include "platform.hpp"
#include <stdio.h>
#include <string>
#include <vector>

// Куда класть файл из торрента. Возвращает путь на SD; пустая строка — файл не копировать на SD (NSP → установка).
// is_switch — файл относится к структуре switch/atmosphere/config (порты, хомбрю, моды).
std::string route_dest(const std::string& root, const std::string& tname, bool multi, const std::string& rel,
                       bool has_nro, bool* is_switch = nullptr);

// Человекочитаемое назначение для предпросмотра: «установка NSP», «switch/…», «downloads/…».
std::string route_label(const Meta& m, size_t idx, bool install_nsp, bool raw = false);

// Откуда продолжать после прерывания
struct ResumeInfo {
    size_t idx = 0;          // индекс файла, на котором остановились
    uint64_t off = 0;        // сколько байт обычного файла уже лежит на SD
    std::string inst;        // состояние установки NSP (Installer::state())
};

// Путь на SD, куда router положит обычный файл торрента (для проверки докачки)
std::string plain_dest(Platform* pf, const Meta& m, size_t idx, bool raw = false);

// Режим «в папку»: всё как есть, без установки, без раскладки по switch/… и без распаковки zip.
// Один файл → archive_nintendo/downloads/<файл>; несколько → archive_nintendo/downloads/<название>/<путь>.
std::string raw_dest(const std::string& root, const std::string& tname, bool multi, const std::string& rel);

class Router : public Sink {
public:
    Router(Platform* pf, bool install_nsp, int storage, const ResumeInfo& r = ResumeInfo(), bool raw = false)
        : pf_(pf), install_(install_nsp && !raw), storage_(storage), resume_(r), raw_(raw) {}
    ~Router() override { abort(); }
    bool file_begin(const Meta& m, size_t idx) override;
    bool file_data(const uint8_t* p, size_t n, uint64_t file_off) override;
    bool file_end() override;
    bool seek_request(uint64_t& off) override { return inst_ ? inst_->take_seek(off) : false; }
    std::string error() override { return err_; }
    void abort();                       // полный откат текущего файла (отмена)
    void suspend();                     // остановка с сохранением: данные на SD и частичная установка остаются
    void flush();                       // сбросить буфер записи на SD
    uint64_t file_pos() const { return wrote_; }          // сколько байт текущего обычного файла записано
    std::string inst_state() const;                       // состояние установки NSP для сохранения
    bool in_nsp() const { return inst_ != nullptr; }

    const std::string& current_name() const { return cur_name_; }
    bool installing() const { return inst_ != nullptr; }
    uint64_t inst_bytes() const { return inst_bytes_; }          // позиция в NSP (пропущенное тоже считается установленным)
    uint64_t inst_total() const { return inst_total_; }
    int n_installed() const { return n_installed_; }
    int n_routed() const { return n_routed_; }
    const std::string& last_info() const { return last_info_; }
    std::string summary() const;

private:
    Platform* pf_;
    bool install_;
    int storage_;
    ResumeInfo resume_;
    bool raw_ = false;
    std::string susp_state_;
    std::string err_, cur_name_, last_info_, cur_dest_;
    FILE* fp_ = nullptr;
    Installer* inst_ = nullptr;
    uint64_t inst_bytes_ = 0, inst_total_ = 0, wrote_ = 0;
    int n_installed_ = 0, n_routed_ = 0, n_plain_ = 0, n_zips_ = 0;
    std::string zip_err_;
    bool cur_switch_ = false;
};
