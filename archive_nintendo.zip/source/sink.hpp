#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string>

struct Meta;

// Потребитель данных торрента. Данные идут по порядку файлов; внутри файла — вперёд по смещению.
struct Sink {
    virtual ~Sink() {}
    virtual bool file_begin(const Meta& m, size_t idx) = 0;
    // file_off — смещение данных внутри файла (после seek может «перепрыгнуть» вперёд)
    virtual bool file_data(const uint8_t* p, size_t n, uint64_t file_off) = 0;
    virtual bool file_end() = 0;
    // Приёмник может попросить пропустить часть текущего файла (уже установлено) — вернуть true и смещение.
    virtual bool seek_request(uint64_t& file_off) { (void)file_off; return false; }
    virtual std::string error() = 0;
};
